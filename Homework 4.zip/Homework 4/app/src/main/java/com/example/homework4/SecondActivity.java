package com.example.homework4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class SecondActivity extends AppCompatActivity {
    public static String flagIn=null;//String that will receive string data (country name) when a qualified item from the menu is selected
    ImageView image;//linking to ImageView in xml
    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {//Menu Creation
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {//Menu items
        int id = item.getItemId();
        if (id == R.id.flagDenmark) {
            flagIn = "Denmark";
        }
        if (id == R.id.flagMonaco) {
            flagIn = "Monaco";
        }
        if (id == R.id.flagIsrael) {
            flagIn = "Israel";
        }
        if (id == R.id.exitApp) {
            finish();//Close App
        }
        return super.onOptionsItemSelected(item);
    } */
        String[] countries;
        Toast[] countryFacts;
        int[] countryFlags;

        @Override
        protected void onCreate (Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_second);

            ListView CountryList = (ListView) findViewById(R.id.CountryList);
            image = (ImageView) findViewById(R.id.flag);
            CreateCountryList();
            CreateCountryFactsList();
            CreateCountryFlagsList();

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, countries);//adapter linking to xml ListView
            CountryList.setAdapter(adapter);

            /*if (flagIn == null) {//receiving String data (country name) when a qualified item from the menu is selected from MainActivity or FirstActivity
                flagIn = intent.getStringExtra(MainActivity.FLAG);
            }
            CountryItemSelected(flagIn);*/
            CountryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String currentCountry = (String) CountryList.getItemAtPosition(i);
                    if (currentCountry == countries[i]){
                        image.setImageResource(countryFlags[i]);
                        countryFacts[i].show();
                    }
                    }
            });
        }

        public void CreateCountryList(){
            countries = new String[15];//ListView of 15 selected countries
            countries[0] = "Albania";
            countries[1] = "Belgium";
            countries[2] = "China";
            countries[3] = "Denmark";
            countries[4] = "Egypt";
            countries[5] = "France";
            countries[6] = "Germany";
            countries[7] = "Hungary";
            countries[8] = "Israel";
            countries[9] = "Jamaica";
            countries[10] = "Kenya";
            countries[11] = "Lebanon";
            countries[12] = "Monaco";
            countries[13] = "Nepal";
            countries[14] = "Oman";
        }
        public void CreateCountryFactsList(){
            countryFacts = new Toast[15];//List of 15 selected country's facts
            countryFacts[0] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 2.8m", Toast.LENGTH_LONG);;
            countryFacts[1] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 11.6m", Toast.LENGTH_LONG);
            countryFacts[2] = Toast.makeText(getApplicationContext(), "Continent: Asia \nPopulation: 1,425m", Toast.LENGTH_LONG);
            countryFacts[3] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 5.9m", Toast.LENGTH_LONG);
            countryFacts[4] = Toast.makeText(getApplicationContext(), "Continent: Africa and Asia \nPopulation: 133.3m", Toast.LENGTH_LONG);
            countryFacts[5] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 64.8m", Toast.LENGTH_LONG);
            countryFacts[6] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 83.3m", Toast.LENGTH_LONG);
            countryFacts[7] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 10.1m", Toast.LENGTH_LONG);
            countryFacts[8] = Toast.makeText(getApplicationContext(), "Continent: Asia \nPopulation: 9.8m", Toast.LENGTH_LONG);
            countryFacts[9] = Toast.makeText(getApplicationContext(), "Continent: South America and North America \nPopulation: 2.8m", Toast.LENGTH_LONG);
            countryFacts[10] = Toast.makeText(getApplicationContext(), "Continent: Africa \nPopulation: 55.5m", Toast.LENGTH_LONG);
            countryFacts[11] = Toast.makeText(getApplicationContext(), "Continent: Asia \nPopulation: 5.3m", Toast.LENGTH_LONG);
            countryFacts[12] = Toast.makeText(getApplicationContext(), "Continent: Europe \nPopulation: 0.036m", Toast.LENGTH_LONG);
            countryFacts[13] = Toast.makeText(getApplicationContext(), "Continent: Asia \nPopulation: 31.1m", Toast.LENGTH_LONG);
            countryFacts[14] = Toast.makeText(getApplicationContext(), "Continent: Asia \nPopulation: 4.7m", Toast.LENGTH_LONG);
        }
        public void CreateCountryFlagsList(){
            countryFlags = new int[15];//list of 15 selected country's flags
            countryFlags[0] = R.drawable.albania_flag;
            countryFlags[1] = R.drawable.belgium;
            countryFlags[2] = R.drawable.china;
            countryFlags[3] = R.drawable.denmark;
            countryFlags[4] = R.drawable.egypt;
            countryFlags[5] = R.drawable.france;
            countryFlags[6] = R.drawable.germany;
            countryFlags[7] = R.drawable.hungary;
            countryFlags[8] = R.drawable.israel;
            countryFlags[9] = R.drawable.jamaica;
            countryFlags[10] = R.drawable.kenya;
            countryFlags[11] = R.drawable.lebanon;
            countryFlags[12] = R.drawable.monaco;
            countryFlags[13] = R.drawable.nepal;
            countryFlags[14] = R.drawable.oman;
        }
        public void CountryItemSelected(String selectedCountry){
            if (selectedCountry == countries[3]) {
                image.setImageResource(countryFlags[3]);
                countryFacts[3].show();
            }
            if (selectedCountry == countries[12]) {
                image.setImageResource(countryFlags[12]);
                countryFacts[12].show();
            }
            if (selectedCountry == countries[8]) {
                image.setImageResource(countryFlags[8]);
                countryFacts[8].show();
            }
        }
    }