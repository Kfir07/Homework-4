package com.example.homework4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;



import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static String FLAG = "flag";//String that will be transmitted to SecondActivity when a qualified item from the menu is selected
    /*@Override
    public boolean onCreateOptionsMenu(Menu menu) {//Menu Creation
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){//Menu items
        int id = item.getItemId();

        if (id==R.id.thirdPageEntry){
            Intent intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.flagDenmark){
            Intent intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            FLAG = "denmark";
            intent.putExtra("Denmark", FLAG);
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.flagMonaco){
            Intent intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            FLAG = "monaco";
            intent.putExtra("Monaco", FLAG);
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.flagIsrael){
            Intent intent = new Intent(MainActivity.this,SecondActivity.class);//Intent creation between MainActivity and SecondActivity
            FLAG = "israel";
            intent.putExtra("Israel",FLAG);
            startActivity(intent);//Intent initiating
        }
        if (id==R.id.exitApp){
            finish();//Close App
            System.exit(0);
        }
        return super.onOptionsItemSelected(item);
    }*/
    Button next;
    CountDownTimer cdt;
    TextView counter;
    int maxTime = 10000, interval =1000;
    int count = maxTime/interval;
    @SuppressLint("MissingInflatedId")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        counter = (TextView)findViewById(R.id.counter);//Timer creation and linking to xml TextView that will show it
        cdt=new CountDownTimer(maxTime,interval) {
            @Override
            public void onTick(long millisUntilFinished) {
                counter.setText(""+count);//Timer counting process
                count--;
            }

            @Override
            public void onFinish() {
                Toast.makeText(MainActivity.this,"Time is up ", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this,FirstActivity.class);//Intent creation between MainActivity and FirstActivity
                startActivity(intent);//Intent initiating
            }
        }.start();
        next = (Button)findViewById(R.id.next);//linking with xml button
        next.setOnClickListener(
                new View.OnClickListener(){//Listener - when the button is pressed
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this,FirstActivity.class);//Intent creation between MainActivity and FirstActivity
                        startActivity(intent);//Intent initiating
                    }

                });

    }


}